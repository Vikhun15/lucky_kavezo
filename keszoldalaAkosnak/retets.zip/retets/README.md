# Lucky Kávézó

 - [Emmet](./docs/emmet.md)
 - [markdown](./docs/markdown.md)

# Képek és ikonok letöltése:
- Pixabay: https://pixabay.com/hu/
- Pexels: https://www.pexels.com/hu-hu/
- Lorem Picsum: https://picsum.photos/
- Freepik: https://www.freepik.com/
- Flaticon: https://www.flaticon.com/




# Hasznos linkek
- https://trello.com A feladatok kiosztásához, munkafolyamat követéséhez
- https://github.com/ Verzió kezelés
- https://validator.w3.org/ W3C HTML validátor
- https://www.figma.com Wireframe elkészítéséhez
- https://imagecompressor.com/ Kép tömörítéshez
- https://getbootstrap.com/docs/4.6/getting-started/introduction/ Bootstrap
- https://code.visualstudio.com/shortcuts/keyboard-shortcuts-windows.pdf VS Code billentyűkombinációk (angol)