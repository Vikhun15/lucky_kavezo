# Emmet

| emmet kód                 |    Mit csinál                |
|------|-----|
|`html:5`|HTML oldal alap sablon |
|`!` | HTML oldal alap sablon |
|`div`| `<div></div>` | 
|`.container>.row>.col-lg-4`| LG 3 oszlopos|

`ctrl`+`space` felugró ablak megjeleníti, hogy mi lesz a kimenet

`enter` emmet rövidítést alakítsuk át html kóddá.


https://docs.emmet.io/cheat-sheet/  