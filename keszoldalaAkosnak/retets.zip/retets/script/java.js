function feliratkozas()
{
    let email = document.getElementById('email').value;

    if(email == "")
    {
        alert("Kérem töltse ki a beviteli mezőt!");
    }
    else{
        alert("Sikeresen feliratkozott! Köszönjük szépen!");
    }
}